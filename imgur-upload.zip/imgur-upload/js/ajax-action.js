
jQuery('#file').live('change', function(){						
	 jQuery("#form_file").on('submit',(function(e) {
		e.preventDefault();
		jQuery( '.mce-panel' ).find('iframe').after('<div class="imgur-upload-loading"><div class="loading"></div></div>');
		 jQuery.ajax({
			url: sb_imgur_ajax.url, 
			type: "POST",             
			data: new FormData(this), 
			contentType: false,      
			cache: false,            
			processData:false,       
			success: function(data)  
			{
				jQuery(  '.mce-panel'  ).find('.imgur-upload-loading').remove();
				tinymce.activeEditor.execCommand('mceInsertContent', false, data);						
				return false;
			}
		}); 
	}));
	var file = jQuery('#file');
	if(file.get(0).files.leight === 0 || file.val() == '') {
		alert('Bạn chưa chọn ảnh nào!');
	} else {
		jQuery("#form_file").submit();
		
		
	}//End if get(0)
});								
