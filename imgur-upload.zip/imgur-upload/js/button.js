(function() {
	tinymce.PluginManager.add('imgur_tc_button', function(editor, url) {
		editor.addButton('imgur_tc_button', {
				title: 'Imgur Uploader',
				icon: 'icon imgur-icon',
				onclick: function() {
					jQuery('body').append('<form action="" method="POST" id="form_file"><input type="file" accept="image/gif,.gif,image/jpeg,.jpg,image/png,.png,.jpeg" id="file" name="file"/></form>');
					jQuery('#file').click();
					
					
					
					
					
					
					
					
					
					
					/*
					editor.windowManager.open({
						title:	'IMGUR UPLOADER',
						html:	'<form action="" method="POST" id="form_file"><input type="file" accept="image/gif,.gif,image/jpeg,.jpg,image/png,.png,.jpeg" id="file" name="file" style="padding: 30px;" title="Click to add Files"/><div id="button_file"><img src="" id="file_preview"/></div></form>',
						width: 	500,
						height:	350,
						buttons:	[{
							text: 'Insert to Imgur.com',
							subtype: 'primary',
							id		: 'imgurinsert',
						}]
					});//editor.windowManager.open({	*/











					
				}//onclick: function() {
		});//editor.addButton('imgur_tc_button', {
	});
})();