<?php
/*
 * Plugin Name: Imgur Uploader
 * Plugin URI: http://codehay.net/
 * Description: Plugin Upload ảnh lên Imgur.com cho wordpress
 * Author: Sơn Trần
 * Version: 1.0
 * Author URI: http://codehay.net
 */
 

	
 add_action('admin_head', 'imgur_add_my_tc_button');
 add_action('admin_enqueue_scripts', 'imgur_tc_css');
 add_action('admin_enqueue_scripts', 'imgur_action_js');


 function imgur_add_my_tc_button() {
	 global $typenow;
	 //Check user premissions
	 if( !current_user_can('edit_posts') && !current_user_can('edit_pages')) {return;}
	 //verify the post type
	 if( !in_array($typenow, array('post', 'page')) ) return;
	 //Check if WYSIWYG is enabled
	 if( get_user_option('rich_editing') == 'true' ) {
		 add_filter('mce_external_plugins', 'imgur_add_tiny_plugin');
		 add_filter('mce_buttons', 'imgur_register_my_tc_button');
	 }
 }
 
 function imgur_add_tiny_plugin($plugin_array) {
	 $plugin_array['imgur_tc_button'] = plugins_url('/js/button.js', __FILE__);
	 return $plugin_array;
 }
 
 function imgur_register_my_tc_button($buttons) {
	 array_push($buttons, 'imgur_tc_button');
	 return $buttons;
 }
 
 function imgur_tc_css() {
	wp_enqueue_style('imgur-tc', plugins_url('/style/style.css', __FILE__));
 }
 
 
function imgur_action_js() {
    wp_enqueue_script('ajax-action', plugins_url('/js/ajax-action.js',__FILE__), array('jquery'), false, true);
    wp_localize_script('ajax-action', 'sb_imgur_ajax', array('url' => plugins_url('/imgur.php',__FILE__)));
}

 